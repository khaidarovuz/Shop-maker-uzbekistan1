"""Shop bot handlerlari paketi."""
